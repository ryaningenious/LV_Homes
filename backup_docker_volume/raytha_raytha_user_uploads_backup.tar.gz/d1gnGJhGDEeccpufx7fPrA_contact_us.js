// GSAP Animations
gsap.registerPlugin(ScrollTrigger);

// Reveal sections on scroll
document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('.reveal-section');

    sections.forEach(section => {
        gsap.fromTo(
            section,
            { opacity: 0, y: 50 },
            {
                opacity: 1,
                y: 0,
                duration: 1,
                scrollTrigger: {
                    trigger: section,
                    start: 'top 80%',
                },
            }
        );
    });
});

// Form Submission
document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
        alert('Your message has been sent!');
        this.reset();
    }, 1000);
});

document.addEventListener("DOMContentLoaded", function () {
    gsap.from(".contact-title", {
        x: 100, // Moves from right
        opacity: 0,
        duration: 2, // Increase duration for slower animation
        ease: "power2.out"
    });

    gsap.from(".contact-description", {
        x: -100, // Moves from left
        opacity: 0,
        duration: 2, // Increase duration for slower animation
        ease: "power2.out",
        delay: 0.5 // Adds a slight delay for a staggered effect
    });
});

